import { createServerClient } from '@supabase/ssr'
import { NextResponse, type NextRequest } from 'next/server'

export async function middleware(request: NextRequest) {
  let supabaseResponse = NextResponse.next({ request })

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() { return request.cookies.getAll() },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value))
          supabaseResponse = NextResponse.next({ request })
          cookiesToSet.forEach(({ name, value, options }) =>
            supabaseResponse.cookies.set(name, value, options)
          )
        },
      },
    }
  )

  const { data: { user } } = await supabase.auth.getUser()
  const path = request.nextUrl.pathname

  // /admin และ /score ต้อง login
  if ((path.startsWith('/admin') || path.startsWith('/score')) && !user) {
    return NextResponse.redirect(new URL('/login', request.url))
  }

  // login แล้วไปหน้า /login ให้ redirect
  if (path === '/login' && user) {
    return NextResponse.redirect(new URL('/score', request.url))
  }

  return supabaseResponse
}

export const config = {
  matcher: ['/admin/:path*', '/score/:path*', '/login'],
}
